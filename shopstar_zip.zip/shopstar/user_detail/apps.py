from django.apps import AppConfig


class UserDetailConfig(AppConfig):
    name = 'user_detail'
