from django.db import models
from phonenumber_field.modelfields import PhoneNumberField
from django.contrib.auth.models import User
from django.db.models.deletion import CASCADE, SET_NULL
from PIL import Image
from django.core.files.storage import default_storage as storage

class Profile(models.Model):
    user_name = models.OneToOneField(to= User,on_delete=CASCADE)
    profile_pic = models.ImageField(upload_to = 'profile_pic',null=True,blank=True)
    full_name = models.CharField(max_length=25,null=True,blank=True)
    age = models.PositiveIntegerField(null=True,blank=True)
    gender = models.CharField(max_length=10,default="Male",choices=(('Male',"Male"),("Female","Female")))
    phone_no = PhoneNumberField(null = True,blank = True)
    cr_date = models.DateTimeField(auto_now_add=True)
      
    
    def save(self, *args, **kwargs):
        super(Profile, self).save(*args, **kwargs)

        if self.profile_pic:
            imag = Image.open(self.profile_pic)
            output_size = (300, 300)
            imag.thumbnail(output_size,Image.ANTIALIAS)
            fh = storage.open(self.profile_pic.name, "w")
            format = 'png'
            imag.save(fh,format)
            fh.close()
                
                
class ShippingAddress(models.Model):
    customer = models.ForeignKey(to = User,on_delete=SET_NULL,null=True)
    order = models.ForeignKey(to = 'order_detail.Order',on_delete=SET_NULL,null=True)
    country = models.CharField(max_length=100, default='India (Currently this service only for india!!)',null=True,blank=True)
    house_no = models.CharField(max_length=100)
    full_address = models.TextField()
    nearest_landmark = models.CharField(max_length=100)
    city = models.CharField(max_length=25)
    state = models.CharField(max_length=25)
    zipcode = models.CharField(max_length=25)
    phone_no = PhoneNumberField()
    add_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return "%s(%s)" %(self.customer,self.city)