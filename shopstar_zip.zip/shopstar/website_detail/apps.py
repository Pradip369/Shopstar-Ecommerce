from django.apps import AppConfig


class WebsiteDetailConfig(AppConfig):
    name = 'website_detail'
