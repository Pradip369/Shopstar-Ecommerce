from django.apps import AppConfig


class OrderDetailConfig(AppConfig):
    name = 'order_detail'
