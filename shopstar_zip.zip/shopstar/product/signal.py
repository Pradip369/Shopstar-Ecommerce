from django.dispatch.dispatcher import receiver
from django.db.models.signals import post_save
from user_detail.models import Profile
from django.contrib.auth.models import User

@receiver(post_save,sender=User)

def save_profile(sender,instance,created,**kw):
    if created:
        Profile.objects.create(user_name=instance)
