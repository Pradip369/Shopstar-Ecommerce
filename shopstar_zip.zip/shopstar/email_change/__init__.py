VERSION = (0, 7, 0, 'alpha', 0)
def get_version():
    version = '%d.%d.%d' % (VERSION[0], VERSION[1], VERSION[2])
    return version