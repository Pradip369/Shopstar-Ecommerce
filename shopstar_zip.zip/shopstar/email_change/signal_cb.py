def signal_callback(sender, **kwargs):
    instance = kwargs['instance']